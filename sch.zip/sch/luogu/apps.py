from django.apps import AppConfig


class LuoguConfig(AppConfig):
    name = 'luogu'
